<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;

class LoginController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request) 
    {
        // Create a UserModel with username and password
        $credentials = new UserModel(request()->get('user_name'), request()->get('password'));

        // Instantiate the Business Layer
        $serviceLogin = new SecurityService();
        
        // Pass credentials to Business Layer
        $isValid = $serviceLogin->login($credentials);
        
        // Determine view to display
      
        if($isValid)
        {
            return View('loginPassed2');
        }
        else 
        {
            return View('loginFailed');
        }
    }
}
