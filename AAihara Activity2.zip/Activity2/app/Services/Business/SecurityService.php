<?php
namespace App\Services\Business;
use App\Models\UserModel;
use App\Services\Data\SecurityDAO;
class SecurityService
{
    // Define properties
    private $verifyCred;
    
    public function login(UserModel $credentials)
    {
        // Instantiate DAL
        $this->verifyCred = new SecurityDAO();
        
        // Return true or false by passing credentials
        // to the object
        return $this->verifyCred->findByUser($credentials);
    }
}

