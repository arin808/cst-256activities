@if(request()->get('user_name') =='arin')
<h3>Arin you have logged in successfully</h3>
@else
<h3>Someone else besides Arin has logged in successfully</h3>
@endif