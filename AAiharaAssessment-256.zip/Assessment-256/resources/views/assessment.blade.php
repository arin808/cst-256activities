<html>
<title>Assessment Form</title>
<h3>Midterm User Form</h3>
	<form action="submitData" method="post">
		{{csrf_field()}}
		<label for="firstName">First Name</label>
		<br/>
		<input type="text" name="firstName" id="firstName"/>
		<br/>
		<br/>
		
		<label for="lastName">Last Name</label>
		<br/>
		<input type="text" name="lastName" id="lastName"/>
		<br/>
		<br/>
		
		<label for="color">Favorite Color</label>
		<br/>
		<input type="text" name="color" id="color"/>
		<br/>
		<br/>
		
		<label for="hobby">Hobby</label>
		<br/>
		<input type="text" name="hobby" id="hobby"/>
		<br/>
		<br/>
		
		<input type="submit" value="Submit"/>
	</form>	
</html>
