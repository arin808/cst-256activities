<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\UserModel;
use App\Services\Business\UserBS;

class UserController
{
    public function index(Request $request)
    {
        //Grab data from form fields
        $first = request()->get('firstName');
        $last = request()->get('lastName');
        $color = request()->get('color');
        $hobby = request()->get('hobby');
        
        //Put data into a new UserModel
        $user = new UserModel($first, $last, $color, $hobby);
        
        $bs = new UserBS();
        
        $match = $bs->compare($user);
        
        if($match)
        {
            $true = "There is a match!";
            //$data = ['first'=>$first, 'last'=>$last,'color'=>$color, 'hobby'=>$hobby, 'match'=>$true];
            echo $first;
            echo "<br>";
            echo $last;
            echo "<br>";
            echo $color;
            echo "<br>";
            echo $hobby;
            echo "<br>";
            echo $true;
        }
        else
        {
            $false = "There is no match.";
            //$data = ['first'=>$first, 'last'=>$last,'color'=>$color, 'hobby'=>$hobby, 'match'=>$false];
            echo $first;
            echo "<br>";
            echo $last;
            echo "<br>";
            echo $color;
            echo "<br>";
            echo $hobby;
            echo "<br>";
            echo $false;
        }
        return view('assessment');
    }
}

