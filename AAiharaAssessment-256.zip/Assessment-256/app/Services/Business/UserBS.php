<?php
namespace App\Services\Business;

use App\Model\UserModel;

class UserBS
{
    public function compare(UserModel $user)
    {
        //Set variable for easy reuse
        $cst = "CST-256";
        
        //Check each model value for a match, and if none of them match, return false
        if($user->getFirstName() == $cst)
        {
            return true;
        }
        if($user->getLastName() == $cst)
        {
            return true;
        }
        if($user->getColor() == $cst)
        {
            return true;
        }
        if($user->getHobby() == $cst)
        {
            return true;
        }
        else 
        {
            return false;
        }
    }
}

