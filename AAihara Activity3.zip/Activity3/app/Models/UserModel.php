<?php

namespace App\Models;

class UserModel
{
    private $username;
    private $password;

    // Class constructor
    public function __construct($user, $pass)
    {
        $this->username = $user;
        $this->password = $pass;
    }
        
    /**
     * Getter method -> username
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Getter method -> password
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

}