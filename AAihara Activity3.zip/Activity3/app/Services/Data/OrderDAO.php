<?php
namespace App\Services\Data;

use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class OrderDAO
{
    private $conn;
    private $dbname = "activity3";
    private $dbQuery;
    private $connection;
    private $dbObj;
    
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
    }
   
    /**
     * Method to add order
     */
    public function addOrder(string $product, int $customerID)
    {
        try
        {
            //define query
            $this->dbquery = "INSERT INTO `order` (Product, CustomerID)
                                VALUES('" . $product . "'," . $customerID. ")";
            
            // If the selected query returns a result set
            //$result = mysqli_query($this->conn, $this->dbquery);
            
            if($this->dbObj->query($this->dbquery))
            {
                //$this->conn->closeDBConnect();
                return true;
            }
            else
            {
                //$this->conn->closeDBConnect();
                return false;
            }
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
        
    }
}

