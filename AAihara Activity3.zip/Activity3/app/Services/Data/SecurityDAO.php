<?php
namespace App\Services\Data;

use App\Models\UserModel;
use Carbon\Exceptions\Exception;

class SecurityDAO
{
    // Define conn string
    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "activity2";
    private $dbquery;
    private $port = 8889;
    
    public function __construct()
    {
        // Create a connection to db
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname, $this->port);
        // Make sure to test conn for errors
    }
    
    /**
     * Method to verify user credentials
     * @param UserModel $user
     */
    public function findByUser(UserModel $credentials)
    {
        try 
        {
            $this->dbquery = "SELECT Username, Password 
                                FROM users 
                                WHERE Username = '". $credentials->getUsername(). "' 
                                AND Password = '". $credentials->getPassword()."'"; 
            // If the selected query returns a result set
            $result = mysqli_query($this->conn, $this->dbquery);
            
            if(mysqli_num_rows($result) > 0)
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            }
            else 
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        } 
        catch (Exception $e) 
        {
            echo $e->getMessage();
        }
        
    }
}

