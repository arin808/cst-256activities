<html>
    <head>
        <title>Add Order</title>
    </head>
    <body>
        <div>
            <form action="addorder" method="post">
            	{{csrf_field()}}
            	<!-- Table Dive -->
            	<div class="demo-table">
            		<div class="form-head">Order Product</div>
            		
            		<!-- Begin Product -->
            		<div class="form-column">
            			<div>
            				<label for="product">Product</label><span id="product-info" class="error-info"></span>
            			</div>
                		<div>
                			<input name="product" id="product" type="text" class="demo-input-box">
                		</div>
                	</div>
                	<!-- End Product -->
                	
                	<!-- Begin CustomerID -->
                	<div class="form-column">
                		<div>
                			<label for="customerID">Customer ID</label><span id="customerID-info" class="error-info"></span>
                		</div>
                    	<div>
                    		<input name="customerID" id="customerID" type="text" class="demo-input-box" value="{{Session::get('nextID')}}">
                    	</div>
                    	<div>
                    		<input name="firstName" id="firstName" type="text" class="demo-input-box" value="{{Session::get('firstName')}}">
                    	</div>
                    	<div>
                    		<input name="lastName" id="lastName" type="text" class="demo-input-box" value="{{Session::get('lastName')}}">
                    	</div>
                	</div>
                	<!-- End Customer -->
                	
                	<!-- Begin Submit -->
                	<div>
                		<input type="submit" class="btnLogin">
                	</div>
                	<!-- End Submit -->
                	
            	</div>
            	<!-- End Table -->
           	</form>
		</div>
	</body>
</html>