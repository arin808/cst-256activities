<?php 

namespace App\Models;

class DTOModel implements \JsonSerializable
{
	private $errorCode;
	private $errorMessage;
	private $data;
	
	public function __construct($errCode, $errMess, $data)
	{
		$this->errorCode = $errCode;
		$this->errorMessage = $errMess;
		$this->data = $data;
	}
	
	/**
	 * @return mixed
	 */
	public function getData()
	{
		return $this->data;
	}

	/**
	 * @param mixed $data
	 */
	public function setData($data)
	{
		$this->data = $data;
	}

	/**
	 * @return mixed
	 */
	public function getErrorCode()
	{
		return $this->errorCode;
	}

	/**
	 * @param mixed $errorCode
	 */
	public function setErrorCode($errorCode)
	{
		$this->errorCode = $errorCode;
	}

	/**
	 * @return mixed
	 */
	public function getErrorMessage()
	{
		return $this->errorMessage;
	}

	/**
	 * @param mixed $errorMessage
	 */
	public function setErrorMessage($errorMessage)
	{
		$this->errorMessage = $errorMessage;
	}

	public function jsonSerialize()
	{
		return get_object_vars($this);
	}
}
?>