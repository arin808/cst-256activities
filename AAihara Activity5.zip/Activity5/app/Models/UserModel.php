<?php

namespace App\Models;
class UserModel implements \JsonSerializable
{
	private $id;
    private $username;
    private $password;

    // Class constructor
    public function __construct($id, $user, $pass)
    {
    	$this->id = $id;
        $this->username = $user;
        $this->password = $pass;
    }
        

	/**
	 * @return mixed
	 */
	public function getId()
	{
		return $this->id;
	}

	/**
	 * @param mixed $id
	 */
	public function setId($id)
	{
		$this->id = $id;
	}

	/**
     * Getter method -> username
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Getter method -> password
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }
	public function jsonSerialize()
	{
		return get_object_vars($this);
	}
}