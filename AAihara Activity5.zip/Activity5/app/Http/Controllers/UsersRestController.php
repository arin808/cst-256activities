<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Data\SecurityDAO;
use App\Services\Business\SecurityService;
use App\Models\DTOModel;
use App\Models\UserModel;

class UsersRestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $service = new SecurityService();
        
        $users = $service->findAllUsers();
       
        $dto = new DTOModel("404", "No data found", $users);
        if($users != null)
        {
        	return json_encode($users);
        }
        else
        {
        	return json_encode($dto);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $service = new SecurityService();
        
        $user = $service->findUserByID($id);
        
        $dto = new DTOModel("404", "No data found", $user);
        
        if(!$user)
        {
        	return json_encode($dto);
        }
        else
        {
        	return json_encode($user);
        }
    }
}
