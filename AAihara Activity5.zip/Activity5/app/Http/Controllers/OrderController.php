<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class OrderController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request) 
    {
        //Put customerdata in a model
        $customerData = new CustomerModel(request()->get('firstName'), request()->get('lastName'));
        
        // Since we aren't using a model, get vals
        $product = request()->get('product');
        // More efficient since it isn't using a method
        $customerID = $request->input('customerID');

        // Instantiate the Business Layer
        $serviceCustomer = new SecurityService();
        
        // Pass order data to Business Layer
        $isValid = $serviceCustomer->addAllInformation($product, $customerID, $customerData);
        
        // Determine view to display
      
        if($isValid)
        {
            echo "Order data added successfully";
        }
        else 
        {
            echo "Order data was not added";
        }
        return view('order');
    }
    
    // Validation added for activity 3
    public function validateForm(Request $request)
    {
        // setup data validation rules for login form
        $rules = ['user_name' => 'Required | Between: 4, 10 | Alpha', 
            'password' => 'Required | Between: 4, 10'];
        
        $this->validate($request, $rules);
    }
}
