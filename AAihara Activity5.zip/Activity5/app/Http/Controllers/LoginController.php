<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class LoginController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request) 
    {
        Log::info("Entering LoginController Index()");
        
        $this->validateForm($request);
        // Create a UserModel with username and password
        $credentials = new UserModel(0, request()->get('user_name'), request()->get('password'));
        Log::info("Parameters are: ", array("username"=> request()->get('user_name'), "password"=>request()->get('password')));
        
        
        // Instantiate the Business Layer
        $serviceLogin = new SecurityService();
        
        // Pass credentials to Business Layer
        $isValid = $serviceLogin->login($credentials);
        
        // Determine view to display
      
        if($isValid)
        {
            Log::info("Exit LoginController::index() with login passing");
            //Added for webpage security
            session()->put('security');
            return View('loginPassed2');
        }
        else 
        {
            Log::info("Exit LoginController::index() with login failed");
            return View('loginFailed');
        }
    }
    
    // Validation added for activity 3
    public function validateForm(Request $request)
    {
        // setup data validation rules for login form
        $rules = ['user_name' => 'Required | Between: 4, 10 | Alpha', 
            'password' => 'Required | Between: 4, 10'];
        
        $this->validate($request, $rules);
    }
    
    public function logout(Request $request)
    {
    	Auth::logout();
    	session()->put('security', 'disabled');
    	return redirect('/login');
    }
}
