<?php
namespace App\Services\Business;
use App\Models\CustomerModel;
use App\Models\UserModel;
use App\Services\Data\SecurityDAO;
use App\Services\Data\CustomerDAO;
use App\Services\Data\OrderDAO;
use App\Services\Data\Utility\DBConnect;
use App\Http\Controllers\CustomerController;

class SecurityService
{
    // Define properties
    private $verifyCred;
    private $addnewCustomer;
    private $addnewOrder;
    private $userDAO;
    
    public function login(UserModel $credentials)
    {
        // Instantiate DAL
        $this->verifyCred = new SecurityDAO();
        
        // Return true or false by passing credentials
        // to the object
        return $this->verifyCred->findByUser($credentials);
    }
    public function addCustomer(CustomerModel $data)
    {
       $this->addnewCustomer = new CustomerDAO();
        
        return $this->addnewCustomer->addCustomer($data);
        
    }
    
    public function addOrder(string $product, int $customerID)
    {
        $this->addnewOrder = new OrderDAO();
        
        return $this->addnewOrder->addOrder($product, $customerID);
    }
    
    //Manage ACID
    public function addAllInformation(string $product, int $customerID, CustomerModel $customerData)
    {
        // Create connection to db
        // Create an instance of the class
        $conn = new DBConnect("activity3");
        $dbObj = $conn->getDBConnect();
        
        // Turn off autocommit
        $conn->setAutocommitFalse();
       
        // Begin transaction
        $conn->beginTransaction();
        
        // Instantiate DAO
        $this->addnewCustomer = new CustomerDAO($dbObj);
        // Get next Customer ID
        $customerID = $this->addnewCustomer->getNextID();
        //Add customer data
        $isSuccessful = $this->addnewCustomer->addCustomer($customerData);
        
        //Instantiate DAO
        $this->addnewOrder = new OrderDAO($dbObj);
        // Add product order data
        $orderSuccess = $this->addnewOrder->addOrder($product, $customerID);
        
        if($isSuccessful && $orderSuccess)
        {
           $conn->commitTransaction();
           return true;
        }
        else 
        {
            $conn->rollbackTransaction();
            return false;
        }
    }
    public function findAllUsers()
    {
    	$this->userDAO = new SecurityDAO();
    	return $this->userDAO->findAllUsers();
    }
    public function findUserByID($id)
    {
    	$this->userDAO = new SecurityDAO();
    	return $this->userDAO->findUserByID($id);
    }
}