<?php
namespace App\Services\Data;

use App\Models\CustomerModel;
use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class CustomerDAO
{
    private $conn;
    private $dbname = "activity3";
    private $dbQuery;
    private $connection;
    private $dbObj;
    
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
    }
    
    /**
     * Method to add customer
     * @param CustomerModel $data
     */
    public function addCustomer(CustomerModel $data)
    {
        try
        {            
            //define query
            $this->dbquery = "INSERT INTO Customer (FirstName, LastName)
                                VALUES('{$data->getFirstName()}','{$data->getLastName()}')";
            
            // If the selected query returns a result set
            //$result = mysqli_query($this->conn, $this->dbquery);
            
            if($this->dbObj->query($this->dbquery))
            {
                //$this->conn->closeDBConnect();
                return true;
            }
            else
            {
                //$this->conn->closeDBConnect();
                return false;
            }
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
        
    }
    
    // ACID
    // Get the next ID from the PK to put in the FK
    public function getNextID()
    {
        try
        {
            // Define the query to get the next ID
            $this->dbQuery = "SELECT CustomerID
                              FROM customer
                              ORDER BY CustomerID DESC LIMIT 0,1";
            
            $result = $this->dbObj->query($this->dbQuery);
            while($row = mysqli_fetch_array($result))
            {
                // Point to the next row that hasn't been committed yet
                return $row['CustomerID'] + 1;
            }
        }
        catch (Exception $e)
        {
            
        }
    }
}

