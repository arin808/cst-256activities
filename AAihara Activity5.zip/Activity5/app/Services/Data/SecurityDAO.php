<?php
namespace App\Services\Data;

use App\Models\UserModel;
use Carbon\Exceptions\Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SecurityDAO
{
    // Define conn string
    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "activity2";
    private $dbquery;
    private $port = 8889;
    
    public function __construct()
    {
        // Create a connection to db
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname, $this->port);
        // Make sure to test conn for errors
    }
    
    /**
     * Method to verify user credentials
     * @param UserModel $user
     */
    public function findByUser(UserModel $credentials)
    {
        try 
        {
            $this->dbquery = "SELECT Username, Password 
                                FROM users 
                                WHERE Username = '". $credentials->getUsername(). "' 
                                AND Password = '". $credentials->getPassword()."'"; 
            // If the selected query returns a result set
            $result = mysqli_query($this->conn, $this->dbquery);
            
            if(mysqli_num_rows($result) > 0)
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            }
            else 
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        } 
        catch (Exception $e) 
        {
            Log::info("Exception SecurityDAO: " . $e->getMessage());
            echo $e->getMessage();
        }
        
    }
    public function findAllUsers()
    {
        try 
        {
            $users = DB::table('users')->get();
            if($users)
            {
	            $userArr = Array();
	            foreach ($users as $user)
	            {
	            	$id = $user->Users_ID;
	            	$userName = $user->Username;
	            	$pass = $user->Password;
	            	
	            	$user = new UserModel($id, $userName, $pass);
	            	array_push($userArr, $user);
	            }
	            
	            return $userArr;
            }
            else
            {
            	return null;
            }
        } 
        catch (Exception $e) 
        {
            $e->getMessage();
        }
    }
    
    public function findUserByID($id)
    {
        try 
        {
         	$data = DB::table('users')->where('Users_ID', $id)->first();
         	if($data)
         	{
	         	$id = $data->Users_ID;
	         	$userName = $data->Username;
	         	$pass = $data->Password;
	         	
	         	$user = new UserModel($id, $userName, $pass);
	         		
	         	return $user;
         	}
         	else
         	{
         		return null;
         	}
         	
        } 
        catch (Exception $e) 
        {
        	$e->getMessage();
        }
    }
}

