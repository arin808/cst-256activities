<?php
namespace App\Services\Data\Utility;

// use App\Models\CustomerModel;
// use Carbon\Exceptions\Exception;
use mysqli;

class DBConnect
{
    // Define conn string
    private $conn;
    private $servername;
    private $username;
    private $password;
    private $dbname;
    private $port;
    
    public function __construct(string $dbname)
    {
        //Initialize properties
        $this->dbname = $dbname;
        $this->servername = "localhost";
        $this->username = "root";
        $this->password = "root";
        $this->port = 8889;
    }

    public function getDBConnect()
    {
        //OOP style
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname, $this->port);
        
        //Procedural style
        // Create a connection to db
        // $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname, $this->port);
        // Make sure to test conn for errors
        
        if($this->conn->connect_errno)
        {
            echo "Failed to connect to MySQL: " . $this->conn->connect_errno;
            exit();
        }
        return ($this->conn);
    }
    /*
     * Close connection
     */
    public function closeDBConnect()
    {
        //OOP style
        $this->conn->close();   
        
        //Procedural style
        //mysqli_close($this->conn);
    }
    
    /*
     * Turn on autocommit 
     */
    public function setDBAutocommitTrue()
    {
        // Turn autcommit on
        $this->conn->autocommit(TRUE);
    }
    
    /*
     * Turn off autocommit
     */
    public function setAutocommitFalse()
    {
        // TUrn autocommit off
        $this->conn->autocommit(FALSE);
    }
        /*
    * Begin a Transaction
    */
    public function beginTransaction()
    {
        $this->conn->begin_transaction();
    }
    
    /*
     * Commit the Transaction
     */
    public function commitTransaction()
    {
        $this->conn->commit();
    }
    
    /*
     * Rollback the transaction
     */
    public function rollbackTransaction()
    {
        $this->conn->rollback();
    }
}