<html>
    <head>
        <title>Add Customer</title>
    </head>
    <body>
        <div>
            <form action="addcustomer" method="post">
            	{{csrf_field()}}
            	<!-- Table Dive -->
            	<div class="demo-table">
            		<div class="form-head">Add Customer</div>
            		
            		<!-- Begin First -->
            		<div class="form-column">
            			<div>
            				<label for="firstName">First Name</label><span id="firstname-info" class="error-info"></span>
            			</div>
                		<div>
                			<input name="firstName" id="firstName" type="text" class="demo-input-box">
                		</div>
                	</div>
                	<!-- End firstname -->
                	
                	<!-- Begin Last -->
                	<div class="form-column">
                		<div>
                			<label for="lastName">Last Name</label><span id="lastname_info" class="error-info"></span>
                		</div>
                    	<div>
                    		<input name="lastName" id="lastName" type="text" class="demo-input-box">
                    	</div>
                	</div>
                	<!-- End Password -->
                	
                	<!-- Begin Submit -->
                	<div>
                		<input type="submit" class="btnLogin">
                	</div>
                	<!-- End Submit -->
                	
            	</div>
            	<!-- End Table -->
           	</form>
		</div>
	</body>
</html>